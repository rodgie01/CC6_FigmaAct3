import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // splashscreenJBT (4:339)
        padding: EdgeInsets.fromLTRB(34*fem, 60*fem, 11*fem, 59*fem),
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Container(
          // frame295b (45:2)
          padding: EdgeInsets.fromLTRB(0.13*fem, 0*fem, 0*fem, 0*fem),
          width: double.infinity,
          height: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // autogrouphe8hS4h (RbV4odD27PobWYGZkFHe8h)
                margin: EdgeInsets.fromLTRB(50.87*fem, 0*fem, 96*fem, 94*fem),
                width: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // vectorwXF (28:1)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                      width: 56*fem,
                      height: 43*fem,
                      child: Image.asset(
                        'assets/page-1/images/vector-Lau.png',
                        width: 56*fem,
                        height: 43*fem,
                      ),
                    ),
                    Text(
                      // consultTP7 (5:24)
                      'CONSULT',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff019874),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // undrawdoctorshwty21hoF (5:189)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 24*fem),
                width: 307.87*fem,
                height: 228*fem,
                child: Image.asset(
                  'assets/page-1/images/undrawdoctorshwty-2-1.png',
                  width: 307.87*fem,
                  height: 228*fem,
                ),
              ),
              Container(
                // autogroupel1xniD (RbV4zCjj9fwHryKVzMEL1X)
                margin: EdgeInsets.fromLTRB(14.87*fem, 0*fem, 0*fem, 31*fem),
                width: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // consultspecialistdoctorssecure (5:0)
                      margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 16*fem, 0*fem),
                      constraints: BoxConstraints (
                        maxWidth: 274*fem,
                      ),
                      child: Text(
                        'Consult Specialist Doctors \nSecurely And Privately',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.5*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // vectorLNM (4056:4)
                      width: 25*fem,
                      height: 20*fem,
                      child: Image.asset(
                        'assets/page-1/images/vector-MPF.png',
                        width: 25*fem,
                        height: 20*fem,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // loremipsumdolorsitametconsecte (4056:2)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.13*fem, 35*fem),
                constraints: BoxConstraints (
                  maxWidth: 253*fem,
                ),
                child: Text(
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Malesuada vulputate facilisi eget neque, nunc suspendisse massa augue. Congue sit augue volutpat vel. Dictum dignissim ac pharetra.',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Roboto',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.1725*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
              Container(
                // autogroupd3gdnNm (RbV57sBdFtY6SxHWvQd3gd)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14.13*fem, 0*fem),
                width: 308*fem,
                height: 58*fem,
                decoration: BoxDecoration (
                  color: Color(0xff019773),
                  borderRadius: BorderRadius.circular(20*fem),
                ),
                child: Center(
                  child: Text(
                    'Get Started',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}