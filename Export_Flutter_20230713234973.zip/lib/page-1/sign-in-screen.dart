import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signinscreensnZ (5:61)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle3QGh (5:62)
              left: 0*fem,
              top: 85*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 727*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x89c4c4c4),
                      borderRadius: BorderRadius.only (
                        topLeft: Radius.circular(40*fem),
                        topRight: Radius.circular(40*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle1UGZ (5:63)
              left: 34*fem,
              top: 704*fem,
              child: Align(
                child: SizedBox(
                  width: 308*fem,
                  height: 58*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(20*fem),
                        color: Color(0xff019773),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle4Kny (5:64)
              left: 34*fem,
              top: 481*fem,
              child: Align(
                child: SizedBox(
                  width: 308*fem,
                  height: 58*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle5dYm (5:65)
              left: 34*fem,
              top: 571*fem,
              child: Align(
                child: SizedBox(
                  width: 308*fem,
                  height: 58*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // enteryouremailY9w (5:66)
              left: 80*fem,
              top: 501*fem,
              child: Align(
                child: SizedBox(
                  width: 108*fem,
                  height: 18*fem,
                  child: Text(
                    'Enter your email',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0x70000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // enteryourpassworddSH (5:67)
              left: 80*fem,
              top: 591*fem,
              child: Align(
                child: SizedBox(
                  width: 137*fem,
                  height: 18*fem,
                  child: Text(
                    'Enter your password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0x70000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // forgotpasswordvwB (5:68)
              left: 119*fem,
              top: 652*fem,
              child: Align(
                child: SizedBox(
                  width: 137*fem,
                  height: 22*fem,
                  child: Text(
                    'Forgot Password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff019874),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // donthaveanaccountsignup3F7 (5:69)
              left: 63.5*fem,
              top: 776*fem,
              child: Align(
                child: SizedBox(
                  width: 249*fem,
                  height: 22*fem,
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff019874),
                      ),
                      children: [
                        TextSpan(
                          text: 'Dont have an account?',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        TextSpan(
                          text: ' ',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff019874),
                          ),
                        ),
                        TextSpan(
                          text: 'Sign Up',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signinBu3 (5:70)
              left: 153*fem,
              top: 718*fem,
              child: Align(
                child: SizedBox(
                  width: 69*fem,
                  height: 30*fem,
                  child: Text(
                    'Sign In',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // undrawmyappgrf211JCy (5:71)
              left: 38*fem,
              top: 266*fem,
              child: Align(
                child: SizedBox(
                  width: 229*fem,
                  height: 172*fem,
                  child: Image.asset(
                    'assets/page-1/images/undrawmyappgrf2-1-1.png',
                    width: 229*fem,
                    height: 172*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // welcomebackAFB (5:92)
              left: 105*fem,
              top: 182*fem,
              child: Align(
                child: SizedBox(
                  width: 166*fem,
                  height: 30*fem,
                  child: Text(
                    'Welcome Back !',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group2FnR (7:434)
              left: 239*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(39*fem, 0*fem, 0*fem, 0*fem),
                width: 238*fem,
                height: 225*fem,
                decoration: BoxDecoration (
                  color: Color(0x60019874),
                  borderRadius: BorderRadius.circular(99.5*fem),
                ),
                child: Align(
                  // ellipse1Z2R (7:436)
                  alignment: Alignment.topRight,
                  child: SizedBox(
                    width: double.infinity,
                    height: 199*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(99.5*fem),
                        color: Color(0x99019874),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // consultGxR (7:446)
              left: 99*fem,
              top: 28*fem,
              child: Align(
                child: SizedBox(
                  width: 118*fem,
                  height: 38*fem,
                  child: Text(
                    'CONSULT',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 25*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.5*ffem/fem,
                      color: Color(0xff019874),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // vectorNVf (28:4)
              left: 35*fem,
              top: 23*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 43*fem,
                  child: Image.asset(
                    'assets/page-1/images/vector-7LM.png',
                    width: 56*fem,
                    height: 43*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}