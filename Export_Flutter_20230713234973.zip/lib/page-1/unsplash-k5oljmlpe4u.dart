import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1280;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // unsplashk5oljmlpe4useh (3312:3)
        width: double.infinity,
        height: 720*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(-1, 0),
            end: Alignment(1, 0),
            colors: <Color>[Color(0xff0ba360), Color(0xff3cba92)],
            stops: <double>[0, 1],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // samsunggalaxynote20ultravcy (5082:37)
              left: 264*fem,
              top: 32*fem,
              child: Container(
                width: 980.75*fem,
                height: 977*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // sumsung3eJ5 (5082:4)
                      left: 0*fem,
                      top: 349*fem,
                      child: Container(
                        width: 848.25*fem,
                        height: 628*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // shadowudK (5082:5)
                              left: 0*fem,
                              top: 55.25*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 848.25*fem,
                                  height: 572.75*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/shadow-KKw.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // samsung3BKw (5082:6)
                              left: 391.5*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 312.5*fem,
                                  height: 551*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/samsung-3.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // camera6xh (5082:7)
                              left: 468.25*fem,
                              top: 38.5*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 8.75*fem,
                                  height: 11.5*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/camera-rEV.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // mockupRzy (5082:8)
                              left: 393.1954650879*fem,
                              top: 9.6516113281*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 296.16*fem,
                                  height: 531.25*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/mockup.png',
                                    width: 296.16*fem,
                                    height: 531.25*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // sumsung2iz5 (5082:14)
                      left: 478.75*fem,
                      top: 170.5*fem,
                      child: Container(
                        width: 332.25*fem,
                        height: 703.25*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // shadowesj (5082:15)
                              left: 0*fem,
                              top: 179.25*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 190.25*fem,
                                  height: 524*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/shadow.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // samsung2P4d (5082:16)
                              left: 47.25*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 285*fem,
                                  height: 556*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/samsung-2.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // cameraULy (5082:17)
                              left: 149.75*fem,
                              top: 23.25*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 10.5*fem,
                                  height: 12*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/camera-MZ3.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // mockupz4R (5082:18)
                              left: 48.5892333984*fem,
                              top: 8.3524169922*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 274.89*fem,
                                  height: 537.36*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/mockup-Fv1.png',
                                    width: 274.89*fem,
                                    height: 537.36*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // sumsung1hUd (5082:24)
                      left: 613*fem,
                      top: 0*fem,
                      child: Container(
                        width: 367.75*fem,
                        height: 725*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // shadowoGm (5082:25)
                              left: 0*fem,
                              top: 171*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 184.5*fem,
                                  height: 554*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/shadow-c3j.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // samsung1jRK (5082:26)
                              left: 96*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 271.75*fem,
                                  height: 560.25*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/samsung-1.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // cameraeYH (5082:27)
                              left: 219.5*fem,
                              top: 14.75*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 11.75*fem,
                                  height: 11.75*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/camera.png',
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // mockupZv9 (5082:28)
                              left: 98.9359741211*fem,
                              top: 7.0072021484*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 266.17*fem,
                                  height: 541.82*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/mockup-EE5.png',
                                    width: 266.17*fem,
                                    height: 541.82*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group7gUy (3312:16)
              left: 0*fem,
              top: 222*fem,
              child: Container(
                width: 742*fem,
                height: 505.82*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // 1n9 (3312:13)
                      left: 0*fem,
                      top: 10.8250732422*fem,
                      child: Align(
                        child: SizedBox(
                          width: 742*fem,
                          height: 494.99*fem,
                          child: Image.asset(
                            'assets/page-1/images/.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vector4jCM (3312:14)
                      left: 372.1087646484*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 67.9*fem,
                          height: 13.78*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-4.png',
                            width: 67.9*fem,
                            height: 13.78*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // usingfigma2BT (3312:19)
                      left: 29*fem,
                      top: 99*fem,
                      child: Align(
                        child: SizedBox(
                          width: 253*fem,
                          height: 57*fem,
                          child: Text(
                            'using Figma',
                            style: SafeGoogleFont (
                              'Philosopher',
                              fontSize: 50*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.12*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle13um3 (3528:20)
              left: 109*fem,
              top: 51*fem,
              child: Align(
                child: SizedBox(
                  width: 374*fem,
                  height: 47*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff454141),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // figmalogo1pt1 (3312:15)
              left: 40*fem,
              top: 30*fem,
              child: Align(
                child: SizedBox(
                  width: 86*fem,
                  height: 86*fem,
                  child: Image.asset(
                    'assets/page-1/images/figma-logo-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // createbeautifulthingsWVw (3528:21)
              left: 179*fem,
              top: 57*fem,
              child: Align(
                child: SizedBox(
                  width: 291*fem,
                  height: 34*fem,
                  child: Text(
                    'Create beautiful things',
                    style: SafeGoogleFont (
                      'Philosopher',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.12*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupoE9 (3312:23)
              left: 473*fem,
              top: 32*fem,
              child: Align(
                child: SizedBox(
                  width: 82*fem,
                  height: 82*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group.png',
                    width: 82*fem,
                    height: 82*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // doctorconsultappWuF (3312:17)
              left: 26*fem,
              top: 136*fem,
              child: Align(
                child: SizedBox(
                  width: 694*fem,
                  height: 90*fem,
                  child: Text(
                    'DOCTOR CONSULT APP',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 60*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // designCn5 (3312:18)
              left: 28*fem,
              top: 222*fem,
              child: Align(
                child: SizedBox(
                  width: 227*fem,
                  height: 90*fem,
                  child: Text(
                    'DESIGN',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 60*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}