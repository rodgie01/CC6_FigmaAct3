import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // welcomescreenJ8y (5:104)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup2d21DWq (RbV95FbQmer6Twb3Lu2D21)
              padding: EdgeInsets.fromLTRB(31*fem, 0*fem, 0*fem, 18.93*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogrouplqdfGED (RbV6pEXPPq7JAXfLC1LQDf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                    width: double.infinity,
                    height: 225*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // vectorBc5 (5:140)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 78*fem, 48*fem),
                          width: 22*fem,
                          height: 21*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-Ugq.png',
                            width: 22*fem,
                            height: 21*fem,
                          ),
                        ),
                        Container(
                          // autogroupb2kq7Eq (RbV76E4jswEN5o9ySUb2kq)
                          width: 344*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // group24fs (5:101)
                                left: 106*fem,
                                top: 0*fem,
                                child: Opacity(
                                  opacity: 0.5,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(39*fem, 0*fem, 0*fem, 0*fem),
                                    width: 238*fem,
                                    height: 225*fem,
                                    decoration: BoxDecoration (
                                      color: Color(0x60019874),
                                      borderRadius: BorderRadius.circular(99.5*fem),
                                    ),
                                    child: Align(
                                      // ellipse1hyj (5:103)
                                      alignment: Alignment.topRight,
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 199*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(99.5*fem),
                                            color: Color(0x99019874),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // helloQt9 (5:135)
                                left: 0*fem,
                                top: 9*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 40*fem,
                                    height: 23*fem,
                                    child: Text(
                                      'Hello,',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // emmanuelsWq (5:142)
                                left: 0*fem,
                                top: 32*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 112*fem,
                                    height: 27*fem,
                                    child: Text(
                                      'Emmanuel !',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 18*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ellipse2AF3 (5:141)
                                left: 168*fem,
                                top: 17*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 43*fem,
                                    height: 43*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(21.5*fem),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-2-bg.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupxhgmFGV (RbV7Kdr4ZpHGcGM155XHgm)
                    margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 29*fem),
                    width: 311*fem,
                    height: 42*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // searchdoctorNM7 (5:144)
                          left: 50*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 107*fem,
                              height: 23*fem,
                              child: Text(
                                'Search Doctor',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0x70000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // vectorEu7 (5:146)
                          left: 18*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 20*fem,
                              height: 22*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-fdB.png',
                                width: 20*fem,
                                height: 22*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // vector9FP (5:148)
                          left: 268*fem,
                          top: 10*fem,
                          child: Align(
                            child: SizedBox(
                              width: 22*fem,
                              height: 21*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-t4h.png',
                                width: 22*fem,
                                height: 21*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle6Tms (5:143)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 311*fem,
                              height: 42*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                  color: Color(0x3d737977),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // doctorsmnZ (5:149)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    width: double.infinity,
                    child: Text(
                      'Doctors',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 30*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroup15sxsKo (RbV7enxoqMnH5Dm3QE15sX)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 9*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // psychologyQKj (5:150)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 0*fem),
                          child: Text(
                            'Psychology',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 18*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // cardiology7jw (5:151)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38.5*fem, 0*fem),
                          child: Text(
                            'Cardiology',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 18*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // gastrology26D (5:152)
                          'Gastrology',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // vector3Fjf (5:153)
                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 0*fem),
                    width: 101*fem,
                    height: 0.07*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-3.png',
                      width: 101*fem,
                      height: 0.07*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbgmxMGu (RbV7z7jwfpWej14jaTbgMX)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
              width: double.infinity,
              height: 280*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle94h7 (5:363)
                    left: 43*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 155*fem,
                        height: 137*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xff019874),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 5*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle8YMP (5:173)
                    left: 22*fem,
                    top: 175*fem,
                    child: Align(
                      child: SizedBox(
                        width: 200*fem,
                        height: 105*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 5*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // drmosiagloriaCwj (5:176)
                    left: 47*fem,
                    top: 189*fem,
                    child: Align(
                      child: SizedBox(
                        width: 145*fem,
                        height: 27*fem,
                        child: Text(
                          'Dr. Mosia Gloria',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // srpsychologistVR3 (5:177)
                    left: 47*fem,
                    top: 211*fem,
                    child: Align(
                      child: SizedBox(
                        width: 116*fem,
                        height: 23*fem,
                        child: Text(
                          'Sr. Psychologist',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0x96000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorAGH (5:183)
                    left: 49*fem,
                    top: 245*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-ZmT.png',
                          width: 16*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vector3qs (5:185)
                    left: 73*fem,
                    top: 245*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector.png',
                          width: 16*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorMrZ (5:186)
                    left: 97*fem,
                    top: 245*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-gx9.png',
                          width: 16*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorUgH (5:187)
                    left: 121*fem,
                    top: 245*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-8u7.png',
                          width: 16*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorP2Z (5:188)
                    left: 145*fem,
                    top: 245*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-pN5.png',
                          width: 16*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vector7UM (5:361)
                    left: 188*fem,
                    top: 249*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 8*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-YNV.png',
                          width: 16*fem,
                          height: 8*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle8QCZ (5:365)
                    left: 254*fem,
                    top: 167*fem,
                    child: Align(
                      child: SizedBox(
                        width: 164*fem,
                        height: 86*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 5*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle9GVf (5:364)
                    left: 261*fem,
                    top: 64*fem,
                    child: Align(
                      child: SizedBox(
                        width: 128*fem,
                        height: 112*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0x99019874),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 5*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // nurse1kQq (5:362)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 250*fem,
                        height: 175*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/nurse-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // nurse214wK (6:0)
                    left: 197*fem,
                    top: 38*fem,
                    child: Align(
                      child: SizedBox(
                        width: 207*fem,
                        height: 138*fem,
                        child: Image.asset(
                          'assets/page-1/images/nurse-2-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // srpsychologistBW9 (5:367)
                    left: 277*fem,
                    top: 197*fem,
                    child: Align(
                      child: SizedBox(
                        width: 93*fem,
                        height: 18*fem,
                        child: Text(
                          'Sr. Psychologist',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0x96000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // drmargretdinaH3P (5:366)
                    left: 277*fem,
                    top: 180*fem,
                    child: Align(
                      child: SizedBox(
                        width: 110*fem,
                        height: 20*fem,
                        child: Text(
                          'Dr. Margret Dina',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorAN5 (5:368)
                    left: 276*fem,
                    top: 221*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-Eob.png',
                          width: 13*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorGR7 (5:369)
                    left: 294*fem,
                    top: 221*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-AC9.png',
                          width: 13*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectoryqK (5:370)
                    left: 312*fem,
                    top: 221*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-YAD.png',
                          width: 13*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorX69 (5:371)
                    left: 330*fem,
                    top: 221*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-sQD.png',
                          width: 13*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorr8R (5:372)
                    left: 348*fem,
                    top: 221*fem,
                    child: Align(
                      child: SizedBox(
                        width: 13*fem,
                        height: 13*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-sGd.png',
                          width: 13*fem,
                          height: 13*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouprjz1xSM (RbV8XrL4neujnJDYJmRjz1)
              width: double.infinity,
              height: 231*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle10Vx5 (7:13)
                    left: 20*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 334*fem,
                        height: 129*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 5*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1BK7 (7:2)
                    left: 0*fem,
                    top: 156*fem,
                    child: Align(
                      child: SizedBox(
                        width: 385*fem,
                        height: 75*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(30*fem),
                            color: Color(0xff019773),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorhYM (7:6)
                    left: 133*fem,
                    top: 178*fem,
                    child: Align(
                      child: SizedBox(
                        width: 20*fem,
                        height: 22*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-zrV.png',
                          width: 20*fem,
                          height: 22*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorCzu (7:4)
                    left: 54*fem,
                    top: 177*fem,
                    child: Align(
                      child: SizedBox(
                        width: 20*fem,
                        height: 17*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-AvD.png',
                          width: 20*fem,
                          height: 17*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorKpd (7:9)
                    left: 212*fem,
                    top: 179*fem,
                    child: Align(
                      child: SizedBox(
                        width: 19.94*fem,
                        height: 19.5*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-6ho.png',
                          width: 19.94*fem,
                          height: 19.5*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorqHB (7:11)
                    left: 291*fem,
                    top: 179*fem,
                    child: Align(
                      child: SizedBox(
                        width: 20*fem,
                        height: 20*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-JKK.png',
                          width: 20*fem,
                          height: 20*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // undrawmedicineb1ol11MmK (7:14)
                    left: 208.0555419922*fem,
                    top: 25.9992523193*fem,
                    child: Align(
                      child: SizedBox(
                        width: 127.94*fem,
                        height: 91*fem,
                        child: Image.asset(
                          'assets/page-1/images/undrawmedicineb1ol-1-1.png',
                          width: 127.94*fem,
                          height: 91*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // instantappointmentrbb (7:180)
                    left: 38*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 165*fem,
                        height: 23*fem,
                        child: Text(
                          'Instant Appointment \n',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // loremipsumdolorsitametconsecte (7:181)
                    left: 38*fem,
                    top: 39*fem,
                    child: Align(
                      child: SizedBox(
                        width: 146*fem,
                        height: 36*fem,
                        child: Text(
                          'Lorem ipsum dolor sit amet, consectetur.',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xa0000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group3n7s (7:390)
                    left: 3*fem,
                    top: 83*fem,
                    child: Container(
                      width: 170*fem,
                      height: 99*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle11uTP (7:182)
                            left: 33*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 105*fem,
                                height: 32*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(20*fem),
                                    color: Color(0xff017c97),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // readmoreChP (7:183)
                            left: 48.5*fem,
                            top: 7*fem,
                            child: Align(
                              child: SizedBox(
                                width: 73*fem,
                                height: 18*fem,
                                child: Text(
                                  'Read more',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}