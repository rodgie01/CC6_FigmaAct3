import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // profilescreenxVF (7:184)
        padding: EdgeInsets.fromLTRB(0*fem, 13*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogrouphfizSvD (RbVAbdDprXbNyyXhqChfiZ)
              width: 519*fem,
              height: 377*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle12x7s (7:391)
                    left: 16*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 344*fem,
                        height: 377*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(28*fem),
                            color: Color(0xff0681a8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // nurse1qSZ (7:392)
                    left: 0*fem,
                    top: 14*fem,
                    child: Align(
                      child: SizedBox(
                        width: 519*fem,
                        height: 363*fem,
                        child: Image.asset(
                          'assets/page-1/images/nurse-1-u2y.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group6k3j (7:455)
                    left: 292*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 49*fem,
                        height: 49*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/group-6.png',
                            width: 49*fem,
                            height: 49*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupvau9Dxu (RbVB4wmdw3PHbPaidfvaU9)
              padding: EdgeInsets.fromLTRB(26.5*fem, 16*fem, 38*fem, 32*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupjpez9bf (RbVAisWkYT7mbtmb9YJPeZ)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 68.5*fem, 49*fem),
                    width: 242*fem,
                    height: 71*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // drmosiagloriagLh (7:393)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 242*fem,
                              height: 45*fem,
                              child: Text(
                                'Dr. Mosia Gloria',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 30*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // srpsychologisthWh (7:394)
                          left: 1.5*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 139*fem,
                              height: 27*fem,
                              child: Text(
                                'Sr. Psychologist',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0x96000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group4Bwf (7:398)
                    margin: EdgeInsets.fromLTRB(11.5*fem, 0*fem, 0*fem, 24*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // patientsigh (7:395)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 53*fem, 0*fem),
                          child: Text(
                            'Patients',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0x96000000),
                            ),
                          ),
                        ),
                        Container(
                          // experienceEuw (7:396)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55*fem, 0*fem),
                          child: Text(
                            'Experience',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0x96000000),
                            ),
                          ),
                        ),
                        Text(
                          // ratingY9w (7:397)
                          'Rating',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0x96000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group55Qm (7:403)
                    margin: EdgeInsets.fromLTRB(22.5*fem, 0*fem, 11.5*fem, 18*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // kDG5 (7:400)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 88*fem, 0*fem),
                          child: Text(
                            '1.4K',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 18*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xb2000000),
                            ),
                          ),
                        ),
                        Container(
                          // yrjkD (7:401)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 87.5*fem, 0*fem),
                          child: Text(
                            '5 yr',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 18*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xb2000000),
                            ),
                          ),
                        ),
                        Text(
                          // 53P (7:402)
                          '4.0',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // about1xd (7:404)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 208.5*fem, 1*fem),
                    child: Text(
                      'About',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // loremipsumdolorsitametconsecte (7:416)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.5*fem, 0*fem),
                    constraints: BoxConstraints (
                      maxWidth: 270*fem,
                    ),
                    child: Text(
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nec quis purus amet sollicitudin nunc quis.',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        color: Color(0xa5000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup56yyUDw (RbVAsnRZuYwp64uzvm56Yy)
              width: double.infinity,
              height: 71*fem,
              decoration: BoxDecoration (
                color: Color(0xff019773),
                borderRadius: BorderRadius.circular(20*fem),
              ),
              child: Center(
                child: Text(
                  'Book Appointment',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.5*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}