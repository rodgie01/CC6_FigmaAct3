import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/iphone-8-1.dart';
// import 'package:myapp/page-1/splash-screen.dart';
// import 'package:myapp/page-1/sign-up-screen.dart';
// import 'package:myapp/page-1/sign-in-screen.dart';
// import 'package:myapp/page-1/welcome-screen.dart';
// import 'package:myapp/page-1/profile-screen.dart';
// import 'package:myapp/page-1/unsplash-k5oljmlpe4u.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
